
<div id="top-news">

</div>
            <div id="blog">
            	<div id="blog_header" >
                	<div class="title_left">TIN TỨC SINH HOẠT</div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 22px">  Bắc Californi: Tiệc Tân Niên Hội Ái Hữu Bạc Liêu Ngày 04/02/2023</p></div>
                  
                  <div> <br> </div>
                
                  <div align= "left"> <p style="font-size : 15px"> Theo lệ hàng năm vào ngày đầu Xuân và mừng Tết Nguyên Đán, hội Ái Hữu Bạc Liêu Bắc California tưng bừng mở tiệc đón mừng Năm Mới tại nhà hàng Dynasty Seafood  vào lúc 5:30pm ngày thứ Bảy 4/2/2023.</p> </div>
                 
                  <div align= "left"> <p style="font-size : 15px"> Tiệc Tân Niên năm Quý Mão còn là dịp kỷ niệm 37 năm hội Bạc Liêu được thành lập. Trên sân khấu trang hoàng những chậu tắc rực rỡ nặng trĩu trái cây vàng, một biểu ngữ căng ngang sân khấu mang hàng chữ “Chào mừng đồng hương, thân hữu Bạc Liêu”. Ban Tổ Chức đón tiếp đồng hương từ 5:00pm.</p> </div>
                
                  <div align= "left"> <p style="font-size : 15px"> Trong không vui mừng đón Xuân sang, có khoảng 500 đồng hương về tham dự hội ngộ. Trong hàng quan khách có Thẩm phán Phan Quang Tuệ, Cụu Tổnng trưởng Kinh Tế VNCH Ông Nguyễn Đức Cường, Hội Cà Mau, Hội An Giang,  và nhiều thân hữu cựu quân nhân công chức tòng sự tại Bạc Liêu. Có những vị khách đền từ xa. </p> </div>

                 <div align= "left"> <p style="font-size : 15px"> Lúc 7:00pm lễ chào cờ khai mạc, tưởng nhớ tiền nhân do Ông Lưu Trường Thọ điều khiển. Sau đó MC Nguyễn Thu Hương giới thiêu ông Hội trưởng Lưu Trường Kiện ngỏ lời chào mừng đồng hương, quan khách. Ông chúc Tết đồng hương. Sau đó ông cho biết hội lớn mạnh được là nhờ tất cả đồng hương thương yêu, góp tay, chung sức để xây dựng. Ông cho biết năm nay ông hết nhiệm kỳ và sẽ bàn giao lai cho vị Tân Hội Trưởng. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Tiếp đến Ông Huỳnh Ngọc Ẩn cho biết hội Bạc Liêu tổ chức tiệc Tân Niên là dịp để đồng hương và thân hữu đến chung vui, họp mặt, chúc Tết. Tiếp đến, DS Nguyễn Văn Bảy, Cố vấn, giới thiệu Tân Hội trường là ông Nguyễn Bình Hoà. Người hội trưởng mới là ông Nguyễn Bình Hoà nhận lãnh trách nhiệm và ngỏ lời chào mừng, hứa hoàn thành công tác đồng hương giáo phó.  </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Đồng hương Bạc Liêu có truyền thống xây dựng hội nhà đoàn kết, giúp đỡ, thương yêu. Hôm nay, nơi xứ người, những người con của Bạc Liêu đã từng uống nước Gành Hào, Giồng Ké, rạch Lộ, rạch Cái Keo, rạch Gốc, Mỹ Thanh, rạch Lé, rạch Bạc Liêu, Trà Nho,Trà Niêu, Trà Teo, v.v... Đến chung vui là để nhớ lại quê hương Giá Rai, Vĩnh Lợi, Vĩnh Châu và Phước Long.... </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Tiếp tục chương trình là phần múa lân chào mừng, chúc Tết. Ba con Lân rộn ràng trong khách sảnh. Trong dịp Tết không thể thiếu “lì-xì”, tục lệ “lì-xì” lấy hên, các con Lân đi quanh các bàn tiệc chúc Tết và nhận tiền “lì-xì.”Các em nhỏ con cháu Bạc Liêu cũng được nhận quà mừng tết. Ngày Tết không thể thiếu phần xổ số lấy hên: Các phần quà do quý vị đồng hương yểm trợ: Ông Bành Chiêu, Ông Lưu Trường Kiện Ông Lâm Hòang Sơn, Ông Đường Mậu Thuỷ, PHP, Ông Lưu Thành ( New Tung Kee ), Ông Thắng Nguyễn (Phở Nguyễn)… </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Tiếng trống lân rộn ràng, tiếng cười nói xôn xao, không khí Tết tràn ngập nhà hàng. Tiếng ca Hương Thuỷ, Philip Nam, Cẩm Thu  ca sĩ đến từ Nam Cali, và thân hữu Bạc Liêu... mang lại niềm vui và không khí rộn ràng cho buổi tiệc. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Cuộc vui náo nhiệt với những bài ca, kể chuyện vui. Trong khi đó các bàn tiệc đã tìm đến nhau tay bắt mặt mừng, chụp hình kỷ niệm và kể chuyện xưa. Bàn này cũng nhộn nhịp, bàn kia cũng có tiếng cười. Quý ông Huỳnh Ngọc Ẩn, Nguyễn Bình Hòa, Lưu Trường Thọ, Liên Hán Như, Hùng Lương,  Ngô Húa… đi từng bàn chúc Tết. Tại nhiều bàn tiệc các vị  trong Ban Chấp hành như chú rể về nhà mới…đến đâu cũng uống một ly vang đỏ cho mặt mày thêm hồng hào. Ca sĩ Hương Thuỷ hát mấy câu vọng cổ nhắc nhớ về những kỷ niệm của quê hương Bạc Liêu. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Một năm mới có một ngày Tết, một năm mới có dịp ngồi lại với nhau một lần sau những tháng ngày bận rộn trong năm. Niềm vui rạng rỡ trên từng khuôn mặt từ em bé đến cụ già. Có những người bận rộn chuyện đời sống, đến ngày Tết cố gắng thu xếp việc nhà đến chung vui. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Hơn 10 giờ khuya mà tiếng hát của các ca sĩ vẫn còn vang trên sân khấu, đồng hương sau tiệc vẫn tiếp tục ngồi lại chuyện trò. Tiệc chấm dứt vào khoảng nửa khuya. Mọi người ra về trong luyến tiếc. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Ban Chấp Hành Báo cáo cùng đồng hương số tiền yểm trợ tại bàn được khoảng $32,000. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Ông Huỳnh Ngọc Ẩn cho biết “bí kíp” của sự thành công: “Mọi người cùng làm, đồng lòng cùng với nhau và được sự yểm trợ chân thành của đồng hương Bạc Liệu”. Bí kíp đó là tiếp đón nồng hậu, chân tình và biết hy sinh cho công việc chung. Tiệc họp mặt đồng hương là nơi chia xẻ những kỷ niệm. Là dịp để đại gia đình cùng gặp gỡ nhau trong ngày đầu năm, chúc tết, thăm hỏi nhau, v.v... Tưởng cũng nên biết, Hội Ái Hữu Bạc Liêu một năm 2 lần tổ chức cho đồng hương gặp mặt trong dịp Tết và Hè. Cả gia đình cùng có dịp sống bên nhau cùng vui chơi, gặp mặt bà con chòm xóm. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Người ta biết đến Bạc Liêu “Bạc Liêu là xứ cơ cầu” với một nếp sống cần cù, tương trợ. Bạc Liêu nổi tiếng và thương nhớ cho bao người con “xứ cơ cầu” xa quê. Vùng đất mà các di dân đầu tiên đến định cư là vùng ven biển sống bằng nghề đi biển. Biển ở Bạc Liêu được tạo thành từ các bãi bồi với những vùng đất nước mặn có diện tích hàng ngàn mẫu tây. Do biển ở đây có bờ biển thấp, bằng phẳng, thích hợp làm muối. Vùng ven biển có đất giồng cao ráo thuận lợi trồng trọt, làm nhà; có sông có biển cung cấp cá tôm vô tận; thuận lợi cho việc buôn bán… </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Chính vùng đất của Bạc Liêu đã tạo cho người dân tinh thần cộng đồng, tinh thần tương trợ giúp đỡ lẫn nhau. Họ yêu thương nhau như ruột thịt, bằng tinh thần xả thân vì nghĩa. Việc chung sức đồng lòng khai phá một vùng đất mới đã tạo cho người di dân đến vùng đất mới sự đoàn kết mạnh mẽ giữa các sắc dân Việt, Hoa, Miên trên bước đường khai hoang lập ấp, mỗi lưu dân mang theo nền văn hóa ở quê cha đất tổ, hòa hợp với nhau và làm giảu thêm đời sống của vùng đất Bạc Liêu. Và tinh thần đoàn kết, thương yêu đó đã làm cho người Bạc Liêu thành công trên xứ người. Điển hình là người Bạc Liêu tại Bắc California. </p> </div>
                 <div align= "left"> <p style="font-size : 20px"><u> Môt vài nét về Bạc Liêu </u></p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Tên gọi “Bạc Liêu”, đọc giọng Triều Châu là "Pò Léo", có nghĩa là xóm nghèo, làm nghề chài lưới, đánh cá, đi biển. Trước khi người Hoa đến sinh sống, nơi đó là vùng đất Thủy Chân Lạp. Năm 1680, Mạc Cửu là một di thần nhà Minh đến vùng Mang Khảm chiêu tập một số lưu dân người Việt, người Hoa cư trú ở Mang Khảm, Phú Quốc, Rạch Giá, Cà Mau, Lũng Kỳ, Vũng Thơm (hay Kompong som), Cần Bột (Campốt) lập ra những thôn xóm đầu tiên trên vùng đất Bạc Liêu. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Thời kỳ thuộc Pháp: Ngày 20 tháng 12 năm 1899, toàn quyền Đông Dương ký sắc lệnh bỏ xưng danh địa hạt, đổi thành tỉnh. Ngày 1 tháng 1 năm 1900, sắc lệnh trên được áp dụng cho toàn Nam Kỳ. Năm 1904, cắt một phần đất phía bắc của quận Vĩnh Lợi nhập thêm vào quận Vĩnh Châu. Năm 1918, một phần đất phía nam quận Vĩnh Lợi và một phần đất phía bắc Cà Mau được cắt để thành lập quận Giá Rai. Tỉnh lỵ tỉnh Bạc Liêu đặt tại làng Vĩnh Lợi thuộc quận Vĩnh Lợi. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Thời Việt Nam Cộng Hòa: Ngày 9 tháng 3 năm 1956, theo Sắc lệnh 32/VN, Việt Nam Cộng hòa lấy phần lớn diện tích đất của tỉnh Bạc Liêu bao gồm quận Cà Mau, quận Quảng Xuyên và 4 xã của quận Giá Rai là Định Thành, Hoà Thành, Tân thành, Phong Thạnh Tây lập thành tỉnh Cà Mau. Đến ngày 22 tháng 10 năm 1956, chính quyền ra Sắc lệnh 143/VN đổi tên tỉnh Cà Mau thành tỉnh An Xuyên. Năm 1956, tỉnh Bạc Liêu bị giải thể, sáp nhập với tỉnh Sóc Trăng lập thành tỉnh Ba Xuyên. Ngày 8 tháng 9 năm 1964, Việt Nam Cộng Hòa ký Sắc lệnh số 254/NV tái lập tỉnh Bạc Liêu gồm các quận Giá Rai, Vĩnh Lợi, Vĩnh Châu và Phước Long. Tỉnh lỵ Bạc Liêu đặt tại xã Vĩnh Lợi thuộc quận Vĩnh Lợi. </p> </div>
                 <div align= "left"> <p style="font-size : 15px"> Như vậy dù có thay đổi nhiều lần Bạc Liêu là một tỉnh trù phú của VNCH. Nơi đó vang danh khắp Nam Kỳ Lục Tỉnh chuyện Công tử Bạc Liêu. Hội AH Bạc Liêu Bắc California sinh hoạt trong tình đồng hương đằm thắm nghĩa tình, hào phóng. Sau 37 hoạt động càng ngày hội càng phát triển lớn mạnh hơn. </p> </div>
                 
                 <div align= "left"> <p style="font-size : 15px"> <a href="https://www.youtube.com/watch?v=U-90uvNp5Pk" target="_blank">Video Tiệc Tân Niên Hội Ái Hữu Bạc Liêu</a> </p> </div>

                    <div> <br> </div>
                  
                    <div> <br> </div>
                    <div align= "center"> Email : hoibaclieubaccali@sbcglobal.net </div>
                    
                    <div> <br> </div>
                    <div> <br> </div>
                </div>
            
			</div>
 			
            <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">TIN TỨC SINH HOẠT</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,51);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,51);?>
                    </ul>
                  </div>
                 </div>     
			</div>
            
             <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">ĐẶC SẢN BẠC LIÊU</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,52);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,52);?>
                    </ul>
                  </div>
                 </div>  
                 </div>
                <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">HÌNH ẢNH TIỆC MỪNG XUÂN</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,73);?> </div>
                  <div>
	
                  </div>
                 </div>  
                 </div>    
			
</div> 

