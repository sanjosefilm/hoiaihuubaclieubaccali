<div> <br> </div>
<div id="top-news">

</div>
            <div id="blog">
            	<div id="blog_header" >
                	<div class="title_left">Trang Chủ</div>
                  <div> <br> </div>
                    <div align= "center"> <p style="font-size : 22px"> <b> Lễ Phát Thưởng và Họp Mặt Picnic Hè 2023 </b> </p></div>
                    <img src="photos/he2023/1.jpg" alt="he1" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/2.jpg" alt="he2" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/3.jpg" alt="he3" width="740" height="986">
                    <div> <br> </div>
                    <img src="photos/he2023/4.jpg" alt="he4" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/5.jpg" alt="he5" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/6.jpg" alt="he6" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/7.jpg" alt="he7" width="740" height="986">
                    <div> <br> </div>
                    <img src="photos/he2023/8.jpg" alt="he8" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/9.jpg" alt="he9" width="740" height="986">
                    <div> <br> </div>
                    <img src="photos/he2023/10.jpg" alt="he10" width="740" height="986">
                    <div> <br> </div>
                    <img src="photos/he2023/11.jpg" alt="he11" width="740" height="986">
                    <div> <br> </div>
                    <img src="photos/he2023/12.jpg" alt="he12" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/13.jpg" alt="he13" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/14.jpg" alt="he14" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/15.jpg" alt="he15" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/16.jpg" alt="he16" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/17.jpg" alt="he17" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/18.jpg" alt="he18" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/19.jpg" alt="he19" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/20.jpg" alt="he20" width="740" height="520">

                    <div> <br> </div>
                    <img src="photos/he2023/21.jpg" alt="he21" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/22.jpg" alt="he22" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/23.jpg" alt="he23" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/24.jpg" alt="he24" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/25.jpg" alt="he25" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/26.jpg" alt="he26" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/27.jpg" alt="he27" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/30.jpg" alt="he30" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/31.jpg" alt="he31" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/32.jpg" alt="he32" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/33.jpg" alt="he33" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/34.jpg" alt="he34" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/35.jpg" alt="he35" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/36.jpg" alt="he36" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/37.jpg" alt="he37" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/38.jpg" alt="he38" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/39.jpg" alt="he39" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/44.jpg" alt="he44" width="740" height="986">
                    <div> <br> </div>
                    <img src="photos/he2023/45.jpg" alt="he45" width="740" height="986">
                    <div> <br> </div>
                    <img src="photos/he2023/46.jpg" alt="he46" width="740" height="1284">
                    <div> <br> </div>
                    <img src="photos/he2023/47.jpg" alt="he47" width="740" height="1284">
                    <div> <br> </div>
                    <img src="photos/he2023/48.jpg" alt="he48" width="740" height="520">
                    <div> <br> </div>
                    <img src="photos/he2023/49.jpg" alt="he49" width="740" height="520">
                    <div> <br> </div>
                                     
                    <div> <br> </div>
                    <div align= "center"> Email : hoibaclieubaccali@sbcglobal.net </div>
                    
                    <div> <br> </div>
                    <div> <br> </div>
                </div>
			</div>
 			
            <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">TIN TỨC SINH HOẠT</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,51);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,51);?>
                    </ul>
                  </div>
                 </div>     
			</div>
            
             <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">ĐẶC SẢN BẠC LIÊU</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,52);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,52);?>
                    </ul>
                  </div>
                 </div>  
                 </div>
                <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">HÌNH ẢNH TIỆC MỪNG XUÂN </div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,73);?> </div>
                  <div>
	
                  </div>
                 </div>  
                 </div>    
			
</div> 