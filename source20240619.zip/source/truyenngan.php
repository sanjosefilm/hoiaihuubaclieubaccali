
<div id="top-news">

</div>
            <div id="blog">
            	<div id="blog_header" >
                	<div class="title_left">TRUYỆN NGẮN - TÙY BÚT</div>
                    <div> <br> </div>
                    <div align= "left"> <p style="font-size : 20px"> Bạc Liêu Còn Hoài Em Ơi!</p> </div>
                    <div align= "left"> <p style="font-size : 20px"> Chúc</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Bạc Liêu qua bao đời rửa phèn phá đất đã trở nên một vùng phì nhiêu cò bay thẳng cánh. Những ruộng lúa màu mỡ, tu muối mặn mà, đã một thời mang lại một nền Kinh tế phồn thịnh bật nhứt miền hậu giang. Lớp ông cha di dân phần lớn từ Triều Châu xa xôi đến Bạc Liêu, vất vả đi cải đất, đã trỡ nên điền chủ chỉ trong vòng một đời. Họ đã làm nên một nền tảng vững chãi cho thế hệ kế tiếp bỏ lúa, bỏ muối, xuất dương du học, hay lên Sài Gòn học trường Tây và trở thành lớp nhà giàu mới, lớp trí thức mới của Bạc Liêu.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Bạc Liêu đã nở mặt nở mày với “công tử” Trần trinh Huy, một nhân vật rất chịu chơi, xài xả láng cho sáng danh Bạc Liêu. Hay dòng họ nổi tiếng như danh tộc Cao Triều, danh tộc Chung Bá. Điền chủ chức sắc như hội đồng Điều, Ngô Phong Điều, hay hội đồng Trạch,Trần Trinh Trạch cha của công tử Bạc Liêu. Tương truyền hội đồng Trạch ăn mặc làng nhàng lên Sài gòn mua xe bị dealer đuổi ra, bèn bảo người nhà gánh tiền tới. Khiêm tốn hơn từ Giá Rai, Phong Thạnh, Phong Điền con cái điền chủ đã trở thành bác sĩ hay kỹ sư. Bác vật Lưu văn Lang còn lưu lại đồng hồ mặt trời ở Bạc Liêu. Hậu bối bác sĩ Nguyễn tú Vinh, bác sĩ Nguyễn văn Khương, bác sĩ Nguyễn văn Hơn, bác sĩ Tạ ngọc Hà đã mở phòng mạch ở Bạc Liêu cho đến 1975.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Các cơ ngơi, biệt thự của lớp nhà giàu khi đó, của gia đình công tử Bạc Liêu, gia đinh Cao Triều được cất dọc theo sông Cái Bạc Liêu đã trở thành những địa danh trong thành phố.  Dinh hội đồng Điều xa chợ hơn, cất dọc theo bờ sông khúc đổ qua Trà Kha, sau đó chiến tranh nơi đây đã trở thành địa danh bót Hội Đồng Điều định vị cho Xóm mới, lúc đó là vùng ngoại ô của Bạc Liêu.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Trong các dãy phố chợ có một biệt thự hay đúng ra là một khách sạn tên Bungalow. Đây cũng là một địa danh ai cũng biết và dùng để định vị thời đó.  Bungalow nằm trên đường Trương vĩnh Ký do toàn quyền Pháp tạo dựng năm1925 trong chương trình phát triển Đông Dương,  sau thời Tây lọt về chủ Việt Huyện Sổn.  Mỗi năm khi gió bấc thổi về qua phố, trên đường Trương Vĩnh Ký có bầy chim én quay về đất liền đã chọn bungalow làm ổ. Hằng năm đàn én lượn khắp nơi trong phố chợ như nhắc nhở mọi nhà đã sắp qua thêm một năm.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Bạc Liêu từ đó không còn là xứ khỉ ho cò gáy, đã lột xác trù phú, trở thành cái nôi của tiêu khiển trong vùng lục tĩnh, với dòng nhạc đàn ca Tài Tử. Đây là nơi sanh ra bài hát Dạ Cổ Hoài Lang của nhạc sĩ Sáu Lầu, Cao văn lầu, một đệ tử của Hại Khị. Lê Tài khị một người nhạc sĩ khuyến tật nhưng tài tình, ông là hậu tổ của cổ nhạc Bạc Liêu. Sau đó nhạc Tài Tử đã biến hoá thành vọng cổ sáu câu khi các gánh cải lương hình thành và phổ biến khắp miền Lục Tỉnh. Theo đó những rạp hát cũng đã thành hình để đáp ứng nhu cầu tiêu khiển. Bạc Liêu có rạp Chung Bá của gia đinh điền chủ Chung Bá Vạn. Rạp hát cải lương nầy đã gắn liền vào tuổi thơ của tôi cùng với lớp dân Bạc Liêu không mấy gì nổi tiếng, như Ba Tệt, bà Tàu Cua, Ô Cuối, Cô Nía, bà Số quán nhậu, vân vân.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Nhà tôi ở xóm Chung Bá dọc theo dảy rạp hát, đối diện xóm nghèo Chuồng Bò. Khi không có gánh cải lương kéo về rạp Chung Bá vắng hoe. Xóm Chung Bá trừ những lúc có xô bồ bên xóm Chuồng Bò thì cũng khá yên tịnh. Những buổi trưa hè bạn có thể nghe tiếng hát ru con ầu ơ của bà Ba Tệt vọng sang, hay tiếng thoi đưa nhịp từ chiếc bàn dệt vải của cô Chia. Cô Chia con gái của bà Tàu Cua. Gia đình cô thêu một gian của căn nhà ngói ba gian bên xóm Chung Bá. Trước hiên bà Tàu Cua kê một bàn dệt vải. Bà và cô con gái dệt khăn tắm mỏng sọc ca rô. Tôi thường hay qua nhà bà coi dệt vải, đứng nhìn cô Chia dệt và con thoi chạy nhịp nhàng. Thoăng thoắt cô Chia tay kéo tay đẩy khung, chân đạp bàn lên xuống đổi chỉ, giao từng sợi một. Khi cô Chia ngồi bàn dệt thì bà Tàu Cua quay chỉ bên cái quay tay đặt dưới đất. Quay đều, quay đều, quay đều,…. </p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Về sau cô Chia lấy chồng, bàn dệt cũng dẹp đi, vì khi đó Bạc Liêu có điện và có máy dệt. Khi dệt máy về thì dệt tay theo không kịp. Bà Tàu Cua tuy nhiên vẫn tiếp tục quay chỉ gia công cho chủ máy dệt. Chồng cô Chia, Hia Nám nhà cách nhà cô Chia một căn, lấy cô hàng xóm và dọn qua nhà vợ ở. Hai vợ chồng có một xe bán trái cây cắt sẳn, kẹo bánh và thuốc lá lẻ, xe ở gần cầu quay trước tiệm sách Thanh Quang. Đối diện Thanh Quang là khách sạn Trường An. Chủ Trường An có chành lúa ở Giá Rai nếu bạn muốn tìm gốc tích.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Nói về xe bán lẻ ở Bạc Liêu, nổi tiếng nhứt là xe ông Ô Cuối. Ô Cuối là người Tiều nhưng da ông đen như người Miên vì vậy ông có tên Ô - đen.  Xe ông đặt trước một căn phố cạnh tiệm bán đồng hồ Bình Quang ngang cửa chợ nhà lồng Bạc Liêu. Ô Cuối rất chăm chỉ cần mẫn lo làm ăn. Xe ông bán thuốc lá lẻ và trái cây cắt miếng như dưa hấu, khóm, ổi, cóc. Ô Cuối tự tay cắt gọt trái cây để bán. Riêng ngón gọt khóm thuần thục của ông rất đáng để đời. Khóm ông gọt bằng cây dao bang to rộng bản. Ông vạt hai đầu trái khóm chỉ bằng vài nhác dao, sau đó đưa ngược bảng dao vạt phần thân khúc giửa. Vỏ khóm theo sức đẩy của ông vào mép dao, được cắt nguyên bảng thành một mảnh dài.  Rồi cũng bằng con dao bang to tiện mắt, nhấp nháy ông đã gọt xong trái khóm. </p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Ô Cuối tuy vậy nổi tiếng không vì tài gọt khóm. Ông nổi tiếng vì quanh năm suốt tháng ông chỉ vận cái áo thun ba lổ rách nát sau lưng và chiếc quần xà lỏn đen bạt màu. Ngay cả sau khi ông đã ăn nên làm ra bỏ mấy triệu bạc tậu luôn căn phố lầu nơi ông xin đặt xe đứng bán, bộ “đồng phục” của ông vẫn không thay đổi. Tôi nghe nói sau nầy ông có qua Mỹ, có người thấy ông đống bộ veston 3 mảnh trông rất ngon lành.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Trở lại cái máy dệt trong xóm Chung Bá. Ngoài bà Tàu Cua còn có bà Cháng quay chỉ gia công cho máy dệt. Bà Cháng người Tiều như hầu hết các gia đình bên xóm Chung Bá.  Bà qua Việt Nam không biết từ hồi nào nhưng bà nói tiếng Việt không được. Gia đình bà sống trong căn nhà bên hông rạp Chung Bá. Ông Cháng chồng bà được ông Bảy quản lý rạp Chung Bá cho bán đậu phọng rang quạt giấy trong rạp. Hàng của ông để trong một cái sạp nhỏ bên hông khán đường. Trước giờ sân khấu mở màng, ông bưng đậu phọng quạt giấy đi dọc dảy ghế rao mời bán. Trước giờ rạp chánh thức mở cửa, ông vô rạp lo dọn hàng, và ông thường đưa anh em tôi “chui” vào sạp bán trong rạp. Chúng tôi được coi hát “chui” khỏi cần mua vé vào cửa. </p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Phía sau nhà ông Cháng gíap ranh nhà tôi, chổ nhà tôi đặt cái lu nước bên cạnh bàn rửa chén. Bức vách phân chia hai nhà được khoét để một phần miệng lu lấn qua nhà ông Cháng. Bà Cháng có một bàn quay chỉ ở nhà. Bà quay chỉ gia công cho bà Tàu Cua và sau đó cho máy dệt. Khi không quay chỉ bà gánh nước cho nhà bà và lảnh luôn gánh nước mướn cho nhà tôi. Mỗi sáng bà gánh nước vô nhà bà và đổ đầy lu nước nhà tôi.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Trước rạp Chung Bá có cái sân rộng. Đối diện rạp Chung Bá nằm trên đường Trưng Nhị có một dãy nhà trệt. Dãy nhà nầy nằm bên cạnh đình Tân Hưng, giáp ranh sân sau của đình. Cuối dãy nhà bên cạnh con hẽm nhỏ dẫn ra trước sân đinh là Cô Nía, một tư gia thờ Phật Bà Quan Âm. Bà Cháng thường hay qua Cô Nía cúng. Những dịp vía lớn bà Cháng làm bánh đi cúng. Hai thứ bánh thường xuyên của bà  là bánh củ cải Tiều hấp thành từng vắt và bánh bao khoai lang hấp. Những dịp nầy bà canh bà tôi hay chúng tôi khi đang lặt rau hay rửa chén, qua bức vách chung bà luồng qua cho dĩa bánh. Tôi không biết tiếng Tiều nên chỉ cười trừ khi nhận bánh của bà.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Kế nhà ông Cháng là gia đình có tiệm cà phê Ngũ Châu bên cạnh ty thông tin. Nói đến cà phê lúc đó Bạc Liêu chỉ có vài tiệm trong phố như Ngũ Châu, Chái Ủ, Xừng Ký, Quậy Ký. Tôi lúc đó còn rất nhỏ. Thỉnh thoảng ông tôi bảo vào nói bà nội ông lên quán cà phê. Tôi vâng lệnh truyền vào báo bà, bà đưa cho tôi mấy trăm đồng. Lon ton ra nhà trước tôi đưa tiền cho ông và được ông đèo lên xe đạp ra tiệm Quậy Ký. Buổi sáng tiệm rất đông bán cà phê và bánh bao síu mại. Ông tôi gọi ly “phé nại” và bắt chén síu mại từ trong mâm người hầu sáng bưng mời. Lát sau hầu sáng mang lên tách cà phê sửa nóng trên một dĩa lót nhỏ. Ông quậy đều cà phê trong tách xong đổ một chút qua dĩa và quậy cà phê trong dĩa cho nguội trước khi đưa tôi. Tôi hì hụp húp cà phê trong dĩa. </p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Về cà phê Bạc Liêu phải nói đến tiệm Tập Đại Thành, tiệm rang cà phê và bán cà phê sỉ và lẻ. Tiệm nầy nằm bên cạnh chợ Bạc Liêu, kế bên tiệm sách Tường Hưng.  Cà phê Tập Đại Thành không có gì nổi tiếng, chỉ là nơi tôi mua cà phê về bán lẻ trong quán tạp hoá của ba tôi. Gia đình tôi đương nhiên dùng cà phê nầy. Cà phê khi đó pha bằng vợt. Hột cà phê được xây trong cái cối xây tay xong đổ vào cái vợt vải đặt trong cái bình nhôm, đổ nước sôi vào vợt quậy đều một đổi lấy vợt lên, cà phê chảy từ vợt xuống bình. Cà phê làng nhàng, rang khét nghẹt cho ra mùi hăng hắt. Sau nầy ở Mỹ có cà phê đắt tiền rang kiểu Pháp ở Starbucks. Lần đầu uống ly cà phê French dark roast của Starbucks, mùi hăng hắc tôi liên tưởng ngay đến cà phê Tập Đại Thành.</p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Nói đến quán cà phê Bạc Liêu không thể không nhắc đến quán nhậu Bạc Liêu. Trở lại xóm Chung Bá. Ngó xéo qua từ rạp Chung Bá về tay phải trên đường Trưng Nhị là miếng đất trống cỏ hoang mọc cao. Lúc đó hãng dầu Bạc Liêu dùng chổ nầy làm nơi chất mớ thùng phi dầu. Về sau mấy phi dầu dọn đi, đất được phát cỏ dọn nền và hội Hồng Thập Tự Bạc Liêu được cất lên, một cơ nghơi khang trang có một cổng phía trước lúc nào cũng then gài. Chỉ khi cấp phát sửa miễn phí cho trẻ em cổng mới mở rộng. Ngang Hội Hồng Thập Tự là miếng đất trống. Không lâu sau khi cất xong hội thập tự, đất đó cũng được phát cỏ và cất Dạ Lữ Viện Bạc Liêu. Hồi đầu sau khi viện cất xong tôi có thấy đám thợ gặt mướn theo mùa tới Bạc Liêu. Đám thợ nầy ban ngày đi gặt, ban đêm ghé vô Dạ Lữ Viện ngủ. Trước đó đám thợ gặt nầy qua đêm ở trên sân rạp Chung Bá, ngủ trong mấy cái nốp bằng lát đan. Về sau tôi không thấy thợ gặt tới viện nửa, hình như có mấy gia đình gia binh hay công chức đã dọn vào viện, đóng trường kỳ chứ không phải ở qua đêm dạ lữ nữa. </p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Bên hông Dạ Lữ viện phía giáp sân rạp Chung Bá đuợc một tư nhân cất nối ra và mở quán nhậu. Quán nhậu bà Số. Bà Số ở trong dãy nhà dọc theo đường Trưng Trắc cạnh rạp Chung Bá. Tuổi độ bốn mươi không có chồng, bà sống với một bà cụ có lẽ là mẹ chồng và đứa con. Bà cụ gọi bà “A Số”, tiếng Tiều có nghĩa là chị dâu, riết rồi ai cũng gọi bà là bà Số. Từ khi Dạ Lử Viện Bạc Liêu không còn là chốn của khách lữ hành qua đêm đã có quán bà Số mở ngay bên cạnh. Quán bán đồ nhậu và không bảng hiệu. Về sau quán nổi danh ở Bạc Liêu tuy vậy vẫn không có bảng hiệu chính thức. Quán chỉ bán buổi chiều và tối. Hồi đầu quán bán lai rai cho khách rạp hát. Về sau khi quán có các món ăn ngon hơn như lẫu lương, chạo tôm thì quán có sỉ quan tới nhậu. Quán đông khách nhứt khi bộ chỉ huy sư đoàn 21 Bộ binh kéo về đóng ở Bạc Liêu. Cuối tuần xe Jeep chở sỉ quan tới nườm nượp. </p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Sau mấy chục năm xa xứ, mấy năm trước tôi trở về Bạc Liêu. Thành phố thịnh vượng và khang trang hơn nhiều. Ra Nhà Mát nơi lần trước tôi đến để lên tàu ra khơi, chúng tôi tới Chùa Quan Âm. Chùa được xây cất sau đợt Bạc Liêu vượt biên.  Xế chiều có một chị quần áo lèng xèng, đội nón lá rách te tua, lụp xụp bưng cái thúng trong le nghoe vài con cua đi mời khách mua. Chị nói giọng bắc chính thống, một di dân mới của Bạc Liêu. Hơn trăm năm trước nếu có người rao bán ở Nhà Mát, họ đã cất tiếng mời gọi bằng giọng Triều Châu chính thống, đợt di dân đi cải đất Bạc Liêu nguyên thuỷ. Bạc Liêu xứ sở phong phú qua bao đời như nồi hổ lốn, vẫn tiếp tục đón nhận dân di cư từ khắp nơi xa xôi đến rửa phèn cải đất, tìm cơ hội vương lên. </p> </div>
                    <div align= "left"> <p style="font-size : 17px"> Qua bao thế hệ thịnh suy Bạc Liêu với những nổi trôi còn mất, các sinh hoạt Bạc Liêu trong ký ức tôi chỉ đến đây thôi. Bạc Liêu vậy đó.  Xóm Chung Bá vậy đó. Xóm Chung Bá nối dài vậy đó. Bạn ơi đi giáp vòng Bạc Liêu chưa mõi chân, vậy mà chuyện Bạc Liêu kể hoài còn hoài, …. Hoài cố hương ơi!</p> </div>
                    <div align= "left"> <p style="font-size : 20px"> Chúc</p> </div>
                    <div align= "left"> <p style="font-size : 20px"> 2020</p> </div>
                    <div> <br> </div>
                  
                    <div> <br> </div>
                    <div align= "center"> Email : hoibaclieubaccali@sbcglobal.net </div>
                    
                    <div> <br> </div>
                    <div> <br> </div>
                </div>
            
			</div>
 			
            <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">TIN TỨC SINH HOẠT</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,51);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,51);?>
                    </ul>
                  </div>
                 </div>     
			</div>
            
             <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">ĐẶC SẢN BẠC LIÊU</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,52);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,52);?>
                    </ul>
                  </div>
                 </div>  
                 </div>
                <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">HÌNH ẢNH TIỆC MỪNG XUÂN</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,73);?> </div>
                  <div>
	
                  </div>
                 </div>  
                 </div>    
			
</div> 

