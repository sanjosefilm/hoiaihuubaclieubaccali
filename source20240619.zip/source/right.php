<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>

<div id="imags_baclieu">
	<div style="background:#ffad01; color:#FFF; padding:5PX; font-size:12px; font-weight:bold; text-align:center">THƯƠNG MẠI</div>
    <div style="padding-left:2px; padding-right:2px;">
    <?php 
		raovat_content_detail($table_content,69,239);
	?>
    	
    </div>
	
</div>
