<div>
<div id="top-news">
	<?php top_content($table_content,50);
	?>
</div>

            <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">THÔNG BÁO</div>
                    
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,37);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,37);?>
                    </ul>
                  </div>
                 </div>     
			</div>
 
 			
            <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">TIN TỨC SINH HOẠT</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,51);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,51);?>
                    </ul>
                  </div>
                 </div>     
			</div>
            
             <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">ĐẶC SẢN BẠC LIÊU</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,52);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,52);?>
                    </ul>
                  </div>
                 </div>     
			
</div> 
</div>