
<div id="top-news">

</div>
            <div id="blog">
            	<div id="blog_header" >
                	<div class="title_left">THƠ</div>
                    <div align= "center"> <p style="font-size : 22px">  <b>Bạc Liêu Quê Tôi </b></p></div>
                   
                    <div> <br> </div>
                    <div align= "center"><p style="font-size : 18px"> Người có về qua Bạc Liêu không ? </p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nắng Xuân còn thắm má xuân hồng. </p></div>
                    <div align= "center"> <p style="font-size : 18px"> Râm ran tiếng dế thời thơ dại </p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bờ cỏ xanh mềm trong nắng trong.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Chiều về ngang qua CẦU QUAY xưa</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bên kia TU MUỐI gió sang mùa.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đường ra GIỒNG NHÃN kênh đào mới</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Vỏ lãi nổ giòn những sớm trưa.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Nắng sớm trên hương lộ CÁI TRÀM ?</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Chợ bên CẦU SẬP buổi chiều tan.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> HÒA BÌNH, VĨNH MỸ thơm hương lúa</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Phía vuông tôm nước mặn tuôn tràn.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> GIÁ RAI, VĨNH LỢI, PHƯỚC LONG chào !</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Ba mươi năm cũ đã trôi mau.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tìm trong mưa nắng hương hoa đất :</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tìm lá thuyền xưa đỗ bến nào ??</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Chiều ra nhìn XIÊM CÁN bãi xa,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> BUỔI CÁN nước đỏ thắm phú sa.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> GÀNH HAO đón cá tôm về bến</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Có đón người thân từ chốn xa ?</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> BIỂN NHÃN vui mùa thu hoạch mới</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Trái chín vàng thơm ngọt mấy đời.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nhãn đẹp sum suê tàn lá đợi</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đát giồng nồng gió biển ngàn khơi.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Ruộng muối lắng từng ô nước mặn</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Diêm điền nồng đượm vị khơi xa.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Hạt muối kết tinh tình đất Mẹ</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Mặn mòi thơm thảo biển quê Cha.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Cọ tiêng độc huyền vẳng trong mơ,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Lời ca thắm ý bậu mong chờ.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bác SÁU LẦU  canh khuya thao thức</p></div>
                    <div align= "center"> <p style="font-size : 18px"> “ DẠ CỔ HOÀI LANG “ đẫm ý thơ…</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Mái TRƯƠNG CÔNG LẬP thuở ban đầu</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nền cũ gạch tàu, ngói đỏ au.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Trương của bao người con đất BẠC</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nay bốn phương trời nhớ xuyến xao.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Cổng trường Trung Học, sân quần vợt</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Cạnh bên hồ tắm nước long lanh.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đại lộ phủ hang cây rợp bóng.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Thuở thanh bình, táng lá ngát xanh.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Thầy SÂM, Thầy ÁN, Thầy TRUNG NGHĨA</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Cô SẮC, Thầy TÒNG, Thầy TRỌNG ÂN…</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Ơn Thầy Cô miệt mài năm  tháng</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Truyền kiến thức, dạy điều nghĩa nhân.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Trò xưa giờ cánh chim lìa tổ,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đi bốn phương trời bước ruỗi dong.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Phiêu bạt vẫn hoài trông cố độ</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bến nước ngày thơ mãi ngóng trông.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Phương người dầu dãi nhiều năm tháng,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Hình bóng quê xưa chẳng xóa nhòa</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Chan chứa tình thương về cố quán</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Chờ mong tái hợp buổi an hòa.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Dù mai sẽ quay về chốn cũ</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Hay cả đời đất khách tha hương.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Mái tóc năm nào nay bạc trắng</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Thương về đất BẠC mãi tơ vương.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Nhớ sóng lúa ánh vàng mùa gặt hái,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nhớ mắt em tha thiết buổi đăng trình.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tôi tìm về khung trời thơ tuổi dại,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> BẠC LIÊU TRĂM NĂM dào dạt ân tình </p></div>
                   
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 22px">  <b>ĐỢI CHỜ </b></p></div>
                    <img src="photos/doichowaves.jpg" alt="conkhongve" width="740" height="444">
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Rồi khi nào anh về nghe em nói,</p></div>
                    <div align= "center"> <p style="font-size : 18px">Trên bãi chiều em vẫn đứng chờ mong.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Bãi đông đúc khi hạ về nắng chói</p></div>
                    <div align= "center"> <p style="font-size : 18px">Hay đìu hiu bãi vắng lúc tàn đông.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Em đứng đã bao năm nghe sóng vỗ</p></div>
                    <div align= "center"> <p style="font-size : 18px">Biển bên em cát ướt dưới chân trần </p></div>
                    <div align= "center"> <p style="font-size : 18px">Mây phiêu lãng có trôi về cố thổ </p></div>
                    <div align= "center"> <p style="font-size : 18px">Tụ rồi tan cho đẹp nghĩa phù vân?</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Đã bao năm con dã tràng se cát</p></div>
                    <div align= "center"> <p style="font-size : 18px">Viên cát vo tròn đều đặn như khuôn.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Se chăm chỉ bền lâu bên sóng bạc</p></div>
                    <div align= "center"> <p style="font-size : 18px">Se đến vô cùng vô tận ...tháng năm suông.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Rồi con nước lớn ròng theo nhật nguyệt</p></div>
                    <div align= "center"> <p style="font-size : 18px">Lớp lớp xô bờ mặt bể nhấp nhô.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Đợt sóng lớn ầm ào không tưởng tiếc</p></div>
                    <div align= "center"> <p style="font-size : 18px">Công khó dã tràng lại hóa hư vô!!</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Bầy trẻ nhỏ đùa vui trên cát trắng</p></div>
                    <div align= "center"> <p style="font-size : 18px">Cô bé cùng em đào đắp lũy thành</p></div>
                    <div align= "center"> <p style="font-size : 18px">Bên biển xanh miệt mài xây rồi xóa</p></div>
                    <div align= "center"> <p style="font-size : 18px">Má ửng hồng theo nắng sớm lên nhanh.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Em thường gặp bà cụ già tóc trắng</p></div>
                    <div align= "center"> <p style="font-size : 18px">Nheo mắt nhìn nắng chói phía trời xa.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Bà nhớ lắm đứa con mình xa vắng</p></div>
                    <div align= "center"> <p style="font-size : 18px">Ngày tương phùng đợi mãi tháng năm qua.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Bao thuyền nhỏ ra khơi trong đêm trước</p></div>
                    <div align= "center"> <p style="font-size : 18px">Biết mai đây cá có ngập khoang thuyền.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Hương biển mặn thấm như tình đất nước</p></div>
                    <div align= "center"> <p style="font-size : 18px">Thuyền phương nào, về bến có bình yên ?</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Biển chiều lên, thu đông rồi xuân hạ,</p></div>
                    <div align= "center"> <p style="font-size : 18px">Nước đầy vơi năm tháng cũng hao gầy.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Người quên chăng lời người khi từ tạ</p></div>
                    <div align= "center"> <p style="font-size : 18px">Rằng: Bao lâu anh cũng sẽ về đây.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Em đinh ninh lời người bên sóng bạc</p></div>
                    <div align= "center"> <p style="font-size : 18px">Rồi năm nao người sẽ lại quay về.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Trong gió lộng, chim trời ngưng tiếng hát</p></div>
                    <div align= "center"> <p style="font-size : 18px">Em vẫn chờ. Đời trôi tựa cơn mê… </p></div>
                    <div> <br> </div>   
                    
                    <img src="photos/doicho.jpg" alt="conkhongve" width="740" height="2015">
                    <div> <br> </div>
                                  
                    <div align= "center"> <p style="font-size : 22px">  <b> MIÊN TRƯỜNG TRÚC MAI </b></p></div>
                    <img src="photos/mttm.jpg" alt="conkhongve" width="740" height="370">
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Chiều nghiêng bóng nắng lưng đồi, </p></div>
                    <div align= "center"> <p style="font-size : 18px">Em nghiêng bóng nửa thân người trên tôi.</p></div>
                    <div align= "center"> <p style="font-size : 18px">Chao nghiêng cánh nhạn lưng trời,</p></div>
                    <div align= "center"> <p style="font-size : 18px">Em đi biền biệt nửa đời về xa. </p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Rồi qua bao cuộc phong ba </p></div>     
                    <div align= "center"> <p style="font-size : 18px">Tìm em vạn nẻo giang hà. Tìm đâu? </p></div>
                    <div align= "center"> <p style="font-size : 18px">Xuyên bao nhiêu cánh rừng sâu, </p></div>
                    <div align= "center"> <p style="font-size : 18px">Tìm theo vạn lối chân cầu nước trôi. </p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Trường giang chảy một dòng xuôi, </p></div>
                    <div align= "center"> <p style="font-size : 18px">Đổ ra biển lớn, gọi người chân mây. </p></div>
                    <div align= "center"> <p style="font-size : 18px">Sắc hương xưa dẫu tàn phai, </p></div>
                    <div align= "center"> <p style="font-size : 18px">Nghĩa ân vun đắp theo ngày tháng trôi. </p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Dù bao ly cách chia phôi,</p></div>     
                    <div align= "center"> <p style="font-size : 18px">Tình xưa ấp ủ bồi hồi lòng riêng. </p></div>
                    <div align= "center"> <p style="font-size : 18px">Em sang bến khác trăm miền, </p></div>
                    <div align= "center"> <p style="font-size : 18px">Bến xuân, tôi vẫn triền miên đợi người. </p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Qua thêm vạn nẻo đuờng đời</p></div>
                    <div align= "center"> <p style="font-size : 18px">Người xa muôn dặm biển khơi tìm về. </p></div>
                    <div align= "center"> <p style="font-size : 18px">Ngỡ ngàng trên bến sông quê. </p></div>
                    <div align= "center"> <p style="font-size : 18px">Chút tình xưa quyện trăng thề hương xa… </p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px">Trùng lai bên cội mai già, </p></div>     
                    <div align= "center"> <p style="font-size : 18px">Quỳnh tương xin cạn chén ngà đêm hương. </p></div>
                    <div align= "center"> <p style="font-size : 18px">Một lần trao, một đời vương, </p></div>
                    <div align= "center"> <p style="font-size : 18px">Thì trăm năm nguyện: </p></div>
                    <div align= "center"> <p style="font-size : 18px">Miên Trường Trúc Mai. </p></div>
                    <div> <br> </div>

                    <div align= "center"> <p style="font-size : 22px">  <b> ĐÂU CÒN EM BÊN TÔI </b></p></div>
                    <img src="photos/dauconembentoi.jpg" alt="conkhongve" width="740" height="416">
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Gọi tên em vào buổi sáng,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Mặt trời còn khuất chân mây.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Lòng dạt dào tình trìu mến</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Thương làn tóc xỏa vai gầy. </p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Vòng tay ôm em ban trưa</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Lá hoa bừng vui nắng tỏ.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Xuyên qua cành biếc lưa thưa</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bóng đôi mình in vệ cỏ.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Đứng giữa vườn hoa trăm sắc</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Hôn lên suối tóc mây ngàn.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Niềm hạnh phúc này rất thật</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tình yêu dâng tựa suối nguồn.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Ôm phao cùng đùa sóng biển</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Phơi mình tắm nắng Hòn Tre.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Hải âu từng đàn chao liệng.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Lời yêu em đất trời nghe!!</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Ước sẽ cùng em chung lối</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Dù đường trần khổ hay vui.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đỡ nâng đời nhau sớm tối</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Hân hoan, được mất ngậm ngùi.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Chiến chinh làm mình chia biệt,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Rời xa bến nước sông quê</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tình xưa mãi còn tha thiết,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bụi thời gian xóa ngày về.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Bây giờ màn đêm thinh lặng</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tôi gọi tên Em bao lâu.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Em dạt phương nào gió cát.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Để mình tôi với nghẹn ngào…</p></div>
                   
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 22px"> <b> Giang Sơn Hoa Gấm </b> </p></div>
                    <div> <br> </div>
                    <img src="photos/thotranh.jpg" alt="uyenthuylam" width="740" height="520">
                    <div> <br> </div>
                   
                    <div align= "center"> <p style="font-size : 22px">  <b> Sắc Màu </b></p></div>
                    <img src="photos/sacmau.png" alt="uyenthuylam" width="740" height="520">
                    <div align= "center"> <p style="font-size : 18px"> Có phải mầu xanh của núi rừng</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Của cành thông biếc lúc sang xuân</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Của ngàn cây lá và hoa nữa</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Em ở bên ta lúc… ngập ngừng…</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Có phải mầu vàng vầng thái dương</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Rọi soi qua khắp nẻo vô thường</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Áo vàng em gợi thêm nhung nhớ</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Cả một trời thơ rộn sắc hương.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Có phải mầu hồng đôi má say</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Cho đời thêm những nét trang đài</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bao nhiêu hoa đẹp trong vườn thắm</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Cũng sánh chưa bằng môi má ai?</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Với mầu đỏ thẫm của phù sa</p></div>
                    <div align= "center"> <p style="font-size : 18px">Mầu nước Bạch Đằng chiến tích xa </p></div>
                    <div align= "center"> <p style="font-size : 18px"> Máu giặc đỏ tràn trên sóng cả</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Kiên lòng ta giữ vững sơn hà.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Tà áo trinh nguyên trong nắng mai</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Vệ cỏ xanh non in dấu hài</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Em bước ven đồi thơm nắng mới</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Áo trắng quyện lòng ta ngát say.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Giữ bên lòng thu tím lá vàng,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Rừng hoa sim tím cả chiều hoang.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Mực mồng tơi tím loang trên áo,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tuổi ấu thơ trôi biệt dặm ngàn</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Đôi mắt đen huyền trong bóng đêm</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Làn mi cong chớp khẽ ngoan hiền</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Rồi mai gió cuốn chim bay mỏi</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đỗ bến, thuyền neo sông mắt em…</p></div>
                    <div> <br> </div>
                    
                    <div align= "center"> <p style="font-size : 22px"> <b>  Đàn Chim Nhỏ  </b></p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đâu rồi đàn chim nhỏ</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Không về vui bên sân?</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đêm qua trời trở gió</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Mưa giăng mắc xa gần.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Chim về đâu đêm thâu,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Trú nơi nào khỏi ướt?</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Sấm chớp vang mấy lượt,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tơi tả cành hoa ngâu.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Thương đàn chim se sẻ,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Hạt bắp, hạt đậu này.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Chim về sân đi nhé,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Rồi có thức ăn đầy.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Sáng nay vang trong gió,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bầy chim non ngàn khơi,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Vuông sân xanh màu cỏ,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tiếng ríu rít bên đời.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Cành cây chim làm “nhà”,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Góc vườn chim xây tổ.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Bay hoài giữa bao la,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Có không miền  cố thổ?</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Ta như chim tha phương</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Trải tháng năm sương tuyết.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Thấm đôi vầng nhật nguyệt,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Ngùi lòng nhớ cố hương… </p></div>
                 
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 22px">  <b> CON KHÔNG VỀ </b></p></div>
                    <img src="photos/khongve.png" alt="conkhongve" width="740" height="320">
                    <div align= "center"> <p style="font-size : 18px"> Hỏa châu thắp đỏ từng đêm,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Quê hương máu chảy ruột mềm lòng ta.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Vọng vang tiếng súng gần xa,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Mẹ hằng khấn nguyện an hòa cho con.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Đêm đen như dạ héo hon,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Năm cùng tháng tận sao con chưa về.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Cuối đông giá rét não nề</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nhà đơn quạnh quẽ tư bề mưa giăng.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Mẹ già chiếc bóng đơn thân</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Ngóng về biên ải nguyện ân an bình</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Trời làm tan tác mộng lành</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Đất bằng sấm dậy, lìa cành nát quê.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Không bao giờ nữa, con về,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Không bao giờ nữa đường quê chân dồn!</p></div>
                    <div align= "center"> <p style="font-size : 18px"> À ơi! Tiếng khóc mỏi mòn,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Lá vàng khóc lá xanh non lìa cành!</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 22px">  <b> BIẾT ĐÂU TÌM  </b></p></div>
                    <img src="photos/bietdautim.png" alt="conkhongve" width="740" height="586">
                    <div align= "center"> <p style="font-size : 18px"> Anh tìm cả trong rừng xưa cổ tích, </p></div>
                    <div align= "center"> <p style="font-size : 18px"> Anh tìm em qua trăm chốn ngàn phương.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tìm em đâu trên khắp vạn nẻo đường,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Chân rảo bước mà lòng như hối hả.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Tìm nhau trên đường quê hương vạn ngả,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Anh quay về sau nửa kiếp chân mây.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Ngày tạ từ tay nắm lấy bàn tay,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tưởng gặp lại một ngày không xa lắm.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Vậy rồi quá nửa đời trong thinh lặng,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nhớ thương em gió bấc lạnh từng mùa,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Nhớ vô vàn ngày tháng cũ tiêu sơ,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Em ngự trị trong hồn anh đằm thắm.</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Bên trường cũ gốc điệp tàn quạnh vắng,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Thềm rêu xanh dấu hài đã phai nhòa.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Lạc loài ngay trên cả lối quen xưa,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Anh đứng đợi buổi sum vầy hư ảo!</p></div>
                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 18px"> Em nghe chăng đầu thôn vang tiếng pháo,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Có hay anh trọn kiếp đợi tương phùng.</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Em về đâu giữa trời đất mênh mông,</p></div>
                    <div align= "center"> <p style="font-size : 18px"> Tình xưa hỡi! Còn bao giờ tương ngộ ?...</p></div>

                    <div> <br> </div>
                    <div align= "center"> <p style="font-size : 22px">  <b> Nhạc phẩm BIẾT ĐÂU TÌM </b></p></div>
                    <img src="photos/timemdau.jpg" alt="conkhongve" width="740" height="1110">
                    <div> <br> </div>
                    <iframe width="740" height="500" src="https://www.youtube.com/embed/93fOZ1w9K3o">
                    </iframe>
                    <div align= "center"> <p style="font-size : 18px"> UYÊN THÚY LÂM</p></div>
                    <div> <br> </div>
                    <div align= "center"> Email : hoibaclieubaccali@sbcglobal.net </div>
                    
                    <div> <br> </div>
                    <div> <br> </div>
                </div>
            

			</div>
 			
            <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">TIN TỨC SINH HOẠT</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,51);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,51);?>
                    </ul>
                  </div>
                 </div>     
			</div>
            
             <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">ĐẶC SẢN BẠC LIÊU</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,52);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,52);?>
                    </ul>
                  </div>
                 </div>  
                 </div>
                <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">HÌNH ẢNH TIỆC MỪNG XUÂN</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,73);?> </div>
                  <div>
	
                  </div>
                 </div>  
                 </div>    
			
</div> 

