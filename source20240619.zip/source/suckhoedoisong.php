
<div id="top-news">

</div>
            <div id="blog">
            	<div id="blog_header" >
                	<div class="title_left">SỨC KHỎE - ĐỜI SỐNG</div>
                    <div> <br> </div>
                   
                    <div> <br> </div>
                  
                    <div> <br> </div>
                    <div align= "center"> Email : hoibaclieubaccali@sbcglobal.net </div>
                    
                    <div> <br> </div>
                    <div> <br> </div>
                </div>
            
			</div>
 			
            <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">TIN TỨC SINH HOẠT</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,51);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,51);?>
                    </ul>
                  </div>
                 </div>     
			</div>
            
             <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">ĐẶC SẢN BẠC LIÊU</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,52);?> </div>
                  <div>
					<ul>
                    	<?php list_sub($table_content,52);?>
                    </ul>
                  </div>
                 </div>  
                 </div>
                <div id="blog">
            	<div id="blog_header">
                	<div class="title_left">HÌNH ẢNH TIỆC MỪNG XUÂN</div>
                   
                </div>
                <div id="blog_content">
               	  <div class="p-top"> <?php top_content($table_content,73);?> </div>
                  <div>
	
                  </div>
                 </div>  
                 </div>    
			
</div> 

