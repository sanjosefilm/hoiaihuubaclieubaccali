<?php
$left = "source/left.php";
$right = "source/right.php";
$table_content_cat = "content_cat";
$table_content = "content";
$table_product = "product";
$table_video = "video";
$p="data";

/* RAO VAT */
$table_raovat_cat = "raovat_cat";
$table_raovat = "raovat";
$raovat_p = "data_raovat";
$raovat_left = "source/raovat_left.php";
$raovat_right = "source/raovat_right.php";
?>