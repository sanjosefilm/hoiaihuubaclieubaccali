
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>

<div id="menu_left">
    <ul >
        
        <li><div><a href="index.php?p=truyenngan">TRUYỆN NGẮN - TÙY BÚT</a></div>
            
        </li>
        <li><div><a href="index.php?p=tho">THƠ</a></div>
        
        </li>
                        
        <li><div><a href="index.php?p=nhac">NHẠC</a></div>
            
        </li>
        
        <li><div><a href="index.php?p=truyenvuicuoi">TRUYỆN VUI - CƯỜI</a></div>
            
        </li>
        
        <li><div><a href="index.php?p=thamkhaosuutam">THAM KHẢO - SƯU TẦM</a></div>
        
        </li>
         
        <li><div><a href="index.php?p=tinbuon">TIN BUỒN</a></div>
            
        </li>
        
        <li><div><a href="index.php?p=tinvui">TIN VUI</a></div>
            
        </li>                        
        
            <li><div><a href="index.php?p=dacsan">ĐẶC SAN</a></div>
            
        </li>
            <li><div><a href="index.php?p=suckhoedoisong">SỨC KHỎE - ĐỜI SỐNG</a></div>
            
        </li>
        <li><div><a href="index.php?p=hinhanhsinhhoat">HÌNH ẢNH SINH HOẠT</a></div>
        </li>
        
    </ul>
</div>
<br />
<div id="imags_baclieu" >
<div style="background:#ffad01; color:#FFF; padding:5PX; font-size:12px; font-weight:bold; text-align:center">THƯƠNG MẠI</div>
    <div style="padding-left:2px; padding-right:2px;">
    	 <?php 
		raovat_content_detail($table_content,66,238);
	?>
    </div>
</div>    